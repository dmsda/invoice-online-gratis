<?php

if (! function_exists('status_badge_class')) {
    /**
     * Get the Bootstrap badge class based on invoice status.
     *
     * @param string $status
     * @return string
     */
    function status_badge_class(string $status): string
    {
        return match($status) {
            'draft'     => 'bg-secondary',
            'sent'      => 'bg-primary',
            'paid'      => 'bg-success',
            'canceled'  => 'bg-danger',
            default     => 'bg-light text-dark'
        };
    }
}

if (! function_exists('status_label_id')) {
    /**
     * Get the Indonesian label for invoice status.
     *
     * @param string $status
     * @return string
     */
    function status_label_id(string $status): string
    {
        return match($status) {
            'paid'      => 'Lunas',
            'sent'      => 'Terkirim',
            'draft'     => 'Draft',
            'canceled'  => 'Dibatalkan',
            default     => ucfirst($status)
        };
    }
}
