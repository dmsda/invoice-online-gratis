<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice <?= esc($invoice['invoice_number']) ?></title>
    <style>
        body {
            font-family: 'Helvetica', 'Arial', sans-serif;
            color: #333;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background: #f9f9f9;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            padding: 40px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
            border-bottom: 2px solid #eee;
            padding-bottom: 20px;
        }
        .logo img {
            max-height: 80px;
            margin-bottom: 10px;
        }
        .business-info {
            text-align: right;
        }
        .business-name {
            font-size: 24px;
            font-weight: bold;
            color: #2c3e50;
            margin: 0;
        }
        .invoice-title {
            font-size: 32px;
            font-weight: bold;
            color: #2c3e50;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 5px;
        }
        .invoice-details {
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
        }
        .client-info h4, .meta-info h4 {
            margin: 0 0 10px 0;
            font-size: 14px;
            color: #7f8c8d;
            text-transform: uppercase;
        }
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        .items-table th, .items-table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }
        .items-table th {
            background: #f8f9fa;
            text-align: left;
            font-weight: bold;
            color: #2c3e50;
        }
        .items-table td.text-right, .items-table th.text-right {
            text-align: right;
        }
        .totals {
            width: 40%;
            margin-left: auto;
        }
        .totals-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }
        .totals-row.grand-total {
            font-size: 18px;
            font-weight: bold;
            color: #2c3e50;
            border-bottom: 2px solid #2c3e50;
            margin-top: 10px;
        }
        .footer {
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            font-size: 12px;
            color: #7f8c8d;
        }
        .notes {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .bank-info {
            margin-top: 20px;
        }

        @media print {
            body { background: none; padding: 0; }
            .container { box-shadow: none; padding: 0; margin: 0; max-width: 100%; }
            .no-print { display: none; }
        }
    </style>
</head>
<body onload="window.print()">

    <div class="no-print" style="text-align: center; margin-bottom: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; cursor: pointer; background: #3498db; color: #fff; border: none; border-radius: 4px;">Cetak / Simpan PDF</button>
        <button onclick="window.close()" style="padding: 10px 20px; cursor: pointer; background: #95a5a6; color: #fff; border: none; border-radius: 4px; margin-left: 10px;">Tutup</button>
    </div>

    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="logo">
                <?php if(!empty($profile['logo_path'])): ?>
                    <img src="/<?= esc($profile['logo_path']) ?>" alt="Logo">
                <?php endif; ?>
                <div class="business-info" style="text-align: left;">
                    <h1 class="business-name"><?= esc($profile['business_name'] ?? 'Bisnis Saya') ?></h1>
                    <p>
                        <?= nl2br(esc($profile['business_address'])) ?><br>
                        <?= esc($profile['business_phone']) ?> | <?= esc($profile['business_email']) ?>
                    </p>
                </div>
            </div>
            <div style="text-align: right;">
                <h1 class="invoice-title">INVOICE</h1>
                <p>#<?= esc($invoice['invoice_number']) ?></p>
            </div>
        </div>

        <!-- Details -->
        <div class="invoice-details">
            <div class="client-info">
                <h4>Ditagihkan Kepada:</h4>
                <p>
                    <strong><?= esc($invoice['client_name']) ?></strong><br>
                    <?= nl2br(esc($invoice['client_address'])) ?><br>
                    <?= esc($invoice['client_phone']) ?><br>
                    <?= esc($invoice['client_email']) ?>
                </p>
            </div>
            <div class="meta-info" style="text-align: right;">
                <h4>Detail:</h4>
                <p>
                    <strong>Tanggal Terbit:</strong> <?= date('d/m/Y', strtotime($invoice['date_issued'])) ?><br>
                    <strong>Jatuh Tempo:</strong> <?= $invoice['due_date'] ? date('d/m/Y', strtotime($invoice['due_date'])) : '-' ?><br>
                    <strong>Status:</strong> <?= strtoupper($invoice['status']) ?>
                </p>
            </div>
        </div>

        <!-- Items -->
        <table class="items-table">
            <thead>
                <tr>
                    <th>Deskripsi</th>
                    <th class="text-right">Qty</th>
                    <th class="text-right">Harga</th>
                    <th class="text-right">Jumlah</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($items as $item): ?>
                <tr>
                    <td>
                        <strong><?= esc($item['item_name']) ?></strong><br>
                        <small style="color: #7f8c8d;"><?= esc($item['description']) ?></small>
                    </td>
                    <td class="text-right"><?= number_format($item['quantity'], 0, ',', '.') ?></td>
                    <td class="text-right">Rp <?= number_format($item['price'], 0, ',', '.') ?></td>
                    <td class="text-right">Rp <?= number_format($item['amount'], 0, ',', '.') ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="totals">
            <div class="totals-row">
                <span>Subtotal</span>
                <span>Rp <?= number_format($invoice['subtotal'], 0, ',', '.') ?></span>
            </div>
            <?php if($invoice['discount'] > 0): ?>
            <div class="totals-row" style="color: #e74c3c;">
                <span>Diskon</span>
                <span>- Rp <?= number_format($invoice['discount'], 0, ',', '.') ?></span>
            </div>
            <?php endif; ?>
            <?php if($invoice['tax'] > 0): ?>
            <div class="totals-row">
                <span>Pajak</span>
                <span>+ Rp <?= number_format($invoice['tax'], 0, ',', '.') ?></span>
            </div>
            <?php endif; ?>
            <div class="totals-row grand-total">
                <span>Total</span>
                <span>Rp <?= number_format($invoice['total_amount'], 0, ',', '.') ?></span>
            </div>
        </div>

        <?php if($invoice['notes'] || (!empty($profile['bank_name']) && !empty($profile['bank_number']))): ?>
        <div class="footer">
            <?php if($invoice['notes']): ?>
            <div class="notes">
                <strong>Catatan:</strong><br>
                <?= nl2br(esc($invoice['notes'])) ?>
            </div>
            <?php endif; ?>

            <?php if(!empty($profile['bank_name']) && !empty($profile['bank_number'])): ?>
            <div class="bank-info">
                <strong>Pembayaran dapat ditransfer ke:</strong><br>
                <?= esc($profile['bank_name']) ?> - <?= esc($profile['bank_number']) ?><br>
                a.n <?= esc($profile['bank_account_name']) ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <div style="margin-top: 40px; text-align: center; color: #bdc3c7; font-size: 10px;">
            Dibuat menggunakan Invoice Online Gratis
        </div>
    </div>

</body>
</html>
