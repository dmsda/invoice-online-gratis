<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<h2 class="mb-4">Dashboard</h2>

<div class="row mb-4">
    <div class="col-md-3">
        <div class="card text-white bg-primary shadow-sm h-100">
            <div class="card-body">
                <h5 class="card-title">Total Invoice</h5>
                <h2 class="display-4"><?= $totalInvoices ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-warning shadow-sm h-100">
            <div class="card-body">
                <h5 class="card-title">Belum Lunas</h5>
                <h2 class="display-4"><?= $unpaidInvoices ?></h2>
                <small class="text-dark">Draft / Sent</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-success shadow-sm h-100">
            <div class="card-body">
                <h5 class="card-title">Lunas</h5>
                <h2 class="display-4"><?= $paidInvoices ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-info shadow-sm h-100">
            <div class="card-body">
                <h5 class="card-title">Pelanggan</h5>
                <h2 class="display-4"><?= $totalClients ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header bg-white">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Invoice Terakhir</h5>
            <a href="/invoices" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No Invoice</th>
                        <th>Klien</th>
                        <th>Tanggal</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($recentInvoices)): ?>
                        <tr><td colspan="6" class="text-center">Belum ada invoice.</td></tr>
                    <?php else: ?>
                        <?php foreach($recentInvoices as $inv): ?>
                        <tr>
                            <td><strong><?= esc($inv['invoice_number']) ?></strong></td>
                            <td><?= esc($inv['client_name']) ?></td>
                            <td><?= date('d/m/Y', strtotime($inv['date_issued'])) ?></td>
                            <td>Rp <?= number_format($inv['total_amount'], 0, ',', '.') ?></td>
                            <td>
                            <td>
                                <span class="badge <?= status_badge_class($inv['status']) ?>"><?= status_label_id($inv['status']) ?></span>
                            </td>
                            <td>
                                <a href="/invoices/show/<?= $inv['uuid'] ?>" class="btn btn-sm btn-outline-info">Detail</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
