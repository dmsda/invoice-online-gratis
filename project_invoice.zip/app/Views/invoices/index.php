<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h3>Daftar Invoice</h3>
    <a href="/invoices/create" class="btn btn-primary">Buat Invoice Baru</a>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-body">
        <form action="" method="get" class="row g-3 align-items-center">
            <div class="col-auto">
                <select name="status" class="form-select">
                    <option value="">Semua Status</option>
                    <option value="draft" <?= isset($_GET['status']) && $_GET['status'] == 'draft' ? 'selected' : '' ?>>Draft</option>
                    <option value="sent" <?= isset($_GET['status']) && $_GET['status'] == 'sent' ? 'selected' : '' ?>>Sent</option>
                    <option value="paid" <?= isset($_GET['status']) && $_GET['status'] == 'paid' ? 'selected' : '' ?>>Paid</option>
                </select>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-secondary">Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <!-- Desktop Table View -->
        <div class="table-responsive d-none d-md-block">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>No Invoice</th>
                        <th>Tanggal</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($invoices)): ?>
                        <tr><td colspan="5" class="text-center py-4">Belum ada invoice.</td></tr>
                    <?php else: ?>
                        <?php foreach($invoices as $inv): ?>
                        <tr>
                            <td>
                                <strong><?= esc($inv['invoice_number']) ?></strong><br>
                                <small class="text-muted"><?= esc($inv['title']) ?: esc($inv['client_name']) ?></small>
                            </td>
                            <td><?= date('d/m/Y', strtotime($inv['date_issued'])) ?></td>
                            <td>Rp <?= number_format($inv['total_amount'], 0, ',', '.') ?></td>
                            <td>
                                <span class="badge <?= status_badge_class($inv['status']) ?>"><?= status_label_id($inv['status']) ?></span>
                            </td>
                            <td>
                                <a href="/invoices/show/<?= $inv['uuid'] ?>" class="btn btn-sm btn-outline-info">Detail</a>
                                <?php if($inv['status'] == 'draft'): ?>
                                    <a href="/invoices/edit/<?= $inv['uuid'] ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Mobile Card View -->
        <div class="d-md-none">
            <?php if(empty($invoices)): ?>
                <div class="text-center py-4 text-muted">Belum ada invoice.</div>
            <?php else: ?>
                <?php foreach($invoices as $inv): ?>
                <div class="card mb-3 border border-light bg-light shadow-sm">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <div>
                                <h6 class="fw-bold mb-0 text-primary"><?= esc($inv['invoice_number']) ?></h6>
                                <small class="text-muted"><?= date('d/m/Y', strtotime($inv['date_issued'])) ?></small>
                            </div>
                            <span class="badge <?= status_badge_class($inv['status']) ?>"><?= status_label_id($inv['status']) ?></span>
                        </div>
                        <div class="mb-2">
                            <i class="bi bi-person text-secondary me-1"></i> <strong><?= esc($inv['client_name']) ?></strong>
                            <?php if(!empty($inv['title'])): ?>
                                <div class="small text-muted ps-4"><?= esc($inv['title']) ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <h5 class="mb-0 fw-bold">Rp <?= number_format($inv['total_amount'], 0, ',', '.') ?></h5>
                            <div class="d-flex gap-2">
                                <?php if($inv['status'] == 'draft'): ?>
                                    <a href="/invoices/edit/<?= $inv['uuid'] ?>" class="btn btn-sm btn-outline-warning">Edit</a>
                                <?php endif; ?>
                                <a href="/invoices/show/<?= $inv['uuid'] ?>" class="btn btn-sm btn-outline-primary">Lihat Detail <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <div class="mt-3">
            <?= $pager->links() ?>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
