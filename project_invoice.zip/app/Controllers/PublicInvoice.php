<?php

namespace App\Controllers;

use App\Models\InvoiceModel;
use App\Models\InvoiceItemModel;
use App\Models\UserProfileModel;

class PublicInvoice extends BaseController
{
    protected $invoiceModel;
    protected $itemModel;
    protected $profileModel;

    public function __construct()
    {
        $this->invoiceModel = new InvoiceModel();
        $this->itemModel = new InvoiceItemModel();
        $this->profileModel = new UserProfileModel();
    }

    public function index($uuid)
    {
        // 1. Fetch Invoice & Client
        // Note: We don't filter by user_id here because it's public access
        $invoice = $this->invoiceModel->select('invoices.*, clients.client_name, clients.client_address, clients.client_phone, clients.client_email')
                                      ->join('clients', 'clients.id = invoices.client_id', 'left')
                                      ->where('invoices.uuid', $uuid)
                                      ->first();

        if (!$invoice) {
             throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // 2. Security Check: Draft invoices are not public
        if ($invoice['status'] === 'draft') {
            // Option: Redirect to home or show 404
             throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // 3. Fetch Items
        $items = $this->itemModel->where('invoice_id', $invoice['id'])->findAll();

        // 4. Fetch User Profile (Seller Info)
        $profile = $this->profileModel->where('user_id', $invoice['user_id'])->first();

        $data = [
            'invoice' => $invoice,
            'items' => $items,
            'profile' => $profile,
            'title' => 'Invoice ' . $invoice['invoice_number']
        ];

        // Retrieve 'download' query param to trigger PDF generation
        if ($this->request->getGet('action') === 'pdf') {
             return $this->generatePdf($data);
        }

        return view('pdf/invoice', $data);
    }

    private function generatePdf($data)
    {
        $dompdf = new \Dompdf\Dompdf();
        
        // Options
        $options = new \Dompdf\Options();
        $options->set('isRemoteEnabled', true); // Allow remote images if needed (careful)
        $options->set('isHtml5ParserEnabled', true);
        $dompdf->setOptions($options);

        // Render HTML
        $html = view('pdf/invoice', $data);
        $dompdf->loadHtml($html);

        // Setup Paper
        $dompdf->setPaper('A4', 'portrait');

        // Render PDF
        $dompdf->render();

        // Stream to browser
        $filename = 'Invoice-' . $data['invoice']['invoice_number'] . '.pdf';
        
        // Attachment: false means open in browser, true means download
        $dompdf->stream($filename, ["Attachment" => false]);
        exit();
    }
}
