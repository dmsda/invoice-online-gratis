<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header bg-white">
                <h4 class="mb-0">Edit Data Pelanggan</h4>
            </div>
            <div class="card-body">
                <form action="/clients/update/<?= $client['id'] ?>" method="post">
                    <?= csrf_field() ?>
                    
                    <div class="mb-3">
                        <label class="form-label">Nama Pelanggan / Perusahaan <span class="text-danger">*</span></label>
                        <input type="text" name="client_name" class="form-control" value="<?= old('client_name', $client['client_name']) ?>" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">No HP / WhatsApp</label>
                            <input type="text" name="client_phone" class="form-control" value="<?= old('client_phone', $client['client_phone']) ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email (Opsional)</label>
                            <input type="email" name="client_email" class="form-control" value="<?= old('client_email', $client['client_email']) ?>">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Alamat Lengkap</label>
                        <textarea name="client_address" class="form-control" rows="3"><?= old('client_address', $client['client_address']) ?></textarea>
                    </div>

                    <div class="d-flex justify-content-end gap-2">
                        <a href="/clients" class="btn btn-secondary">Batal</a>
                        <button type="submit" class="btn btn-primary">Update Data</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
