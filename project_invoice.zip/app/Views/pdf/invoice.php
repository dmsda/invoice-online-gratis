<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= esc($title) ?></title>
    <style>
        body {
            font-family: 'Helvetica', 'Arial', sans-serif;
            font-size: 14px;
            color: #333;
            line-height: 1.5;
            padding: 8px;
        }
        .header-table {
            width: 100%;
            margin-bottom: 30px;
            border-bottom: 2px solid #ddd;
            padding-bottom: 10px;
        }
        .header-table td {
            vertical-align: top;
        }
        .seller-info h2 {
            margin: 0 0 5px 0;
            color: #2c3e50;
        }
        .seller-info p {
            margin: 0;
            font-size: 13px;
        }
        .invoice-title {
            text-align: right;
        }
        .invoice-title h1 {
            margin: 0 0 5px 0;
            color: #7f8c8d;
            font-size: 24px;
        }
        .invoice-details {
            text-align: right;
            font-size: 13px;
        }
        .client-info {
            background-color: #f9f9f9;
            padding: 15px;
            margin-bottom: 30px;
            border-radius: 4px;
        }
        .client-info h3 {
            margin: 0 0 10px 0;
            font-size: 14px;
            color: #555;
            text-transform: uppercase;
        }
        .client-info p {
            margin: 0;
        }
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        .items-table th {
            background-color: #ecf0f1;
            color: #2c3e50;
            padding: 10px;
            text-align: left;
            border-bottom: 2px solid #bdc3c7;
        }
        .items-table td {
            padding: 10px;
            border-bottom: 1px solid #ecf0f1;
        }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        
        .totals-table {
            width: 100%;
            margin-bottom: 30px;
        }
        .totals-table td {
            padding: 5px 10px;
        }
        .total-row {
            font-weight: bold;
            font-size: 16px;
            background-color: #ecf0f1;
        }
        .notes-section {
            border-top: 1px solid #ddd;
            padding-top: 15px;
            font-size: 12px;
            color: #777;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 8px;
            color: #fff;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }
        .bg-paid { background-color: #27ae60; }
        .bg-sent { background-color: #2980b9; }
        .bg-draft { background-color: #95a5a6; }
        .bg-canceled { background-color: #c0392b; }
    </style>
</head>
<body>

    <!-- Header -->
    <table class="header-table">
        <tr>
            <td width="60%" class="seller-info">
                <?php if(!empty($profile['business_name'])): ?>
                    <h2><?= esc($profile['business_name']) ?></h2>
                    <p><?= nl2br(esc($profile['business_address'])) ?></p>
                    <?php if($profile['business_phone']): ?><p>Telp: <?= esc($profile['business_phone']) ?></p><?php endif; ?>
                    <?php if($profile['business_email']): ?><p>Email: <?= esc($profile['business_email']) ?></p><?php endif; ?>
                <?php else: ?>
                    <h2>Perusahaan Anda</h2>
                <?php endif; ?>
            </td>
            <td width="40%" class="invoice-title">
                <h1>INVOICE</h1>
                <div class="invoice-details">
                    <p><strong>No:</strong> <?= esc($invoice['invoice_number']) ?></p>
                    <p><strong>Tanggal:</strong> <?= date('d/m/Y', strtotime($invoice['date_issued'])) ?></p>
                    <?php if($invoice['due_date']): ?>
                    <p><strong>Jatuh Tempo:</strong> <?= date('d/m/Y', strtotime($invoice['due_date'])) ?></p>
                    <?php endif; ?>
                    
                    <div style="margin-top: 10px;">
                        <?php
                        $badgeClass = match($invoice['status']) {
                            'paid' => 'bg-paid',
                            'sent' => 'bg-sent',
                            'canceled' => 'bg-canceled',
                            default => 'bg-draft'
                        };
                        ?>
                        <span class="status-badge <?= $badgeClass ?>"><?= strtoupper($invoice['status']) ?></span>
                    </div>
                </div>
            </td>
        </tr>
    </table>

    <!-- Client Info -->
    <div class="client-info">
        <h3>Ditagihkan Kepada:</h3>
        <p><strong><?= esc($invoice['client_name']) ?></strong></p>
        <?php if($invoice['client_address']): ?>
        <p><?= nl2br(esc($invoice['client_address'])) ?></p>
        <?php endif; ?>
        <?php if($invoice['client_phone']): ?>
        <p>Telp: <?= esc($invoice['client_phone']) ?></p>
        <?php endif; ?>
    </div>

    <!-- Items -->
    <table class="items-table">
        <thead>
            <tr>
                <th width="45%">Deskripsi</th>
                <th width="15%" class="text-right">Qty</th>
                <th width="20%" class="text-right">Harga</th>
                <th width="20%" class="text-right">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($items as $item): ?>
            <tr>
                <td>
                    <strong><?= esc($item['item_name']) ?></strong>
                    <?php if($item['description']): ?>
                        <br><small style="color: #777;"><?= esc($item['description']) ?></small>
                    <?php endif; ?>
                </td>
                <td class="text-right"><?= number_format($item['quantity'], 0, ',', '.') ?></td>
                <td class="text-right">Rp <?= number_format($item['price'], 0, ',', '.') ?></td>
                <td class="text-right">Rp <?= number_format($item['amount'], 0, ',', '.') ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Totals -->
    <table class="totals-table">
        <tr>
            <td width="60%">
                <!-- Bank Info -->
                <?php if(!empty($profile['bank_name'])): ?>
                <div style="background: #f0f3f4; padding: 10px; font-size: 13px;">
                    <strong>Pembayaran Transfer ke:</strong><br>
                    <?= esc($profile['bank_name']) ?><br>
                    No. Rek: <strong><?= esc($profile['bank_number']) ?></strong><br>
                    A.n: <?= esc($profile['bank_account_name']) ?>
                </div>
                <?php endif; ?>
            </td>
            <td width="40%">
                <table width="100%">
                    <tr>
                        <td class="text-right">Subtotal:</td>
                        <td class="text-right">Rp <?= number_format($invoice['subtotal'], 0, ',', '.') ?></td>
                    </tr>
                    <?php if($invoice['discount'] > 0): ?>
                    <tr>
                        <td class="text-right">Diskon:</td>
                        <td class="text-right">- Rp <?= number_format($invoice['discount'], 0, ',', '.') ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php if($invoice['tax'] > 0): ?>
                    <tr>
                        <td class="text-right">Pajak:</td>
                        <td class="text-right">+ Rp <?= number_format($invoice['tax'], 0, ',', '.') ?></td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <td class="text-right total-row" style="padding-top: 10px;">TOTAL:</td>
                        <td class="text-right total-row" style="padding-top: 10px;">Rp <?= number_format($invoice['total_amount'], 0, ',', '.') ?></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>

    <!-- Notes -->
    <?php if($invoice['notes']): ?>
    <div class="notes-section">
        <strong>Catatan:</strong><br>
        <?= nl2br(esc($invoice['notes'])) ?>
    </div>
    <?php endif; ?>

    <div style="text-align: center; margin-top: 40px; font-size: 11px; color: #aaa;">
        Dibuat otomatis menggunakan <strong>Invoice Online Gratis</strong>
    </div>

</body>
</html>
