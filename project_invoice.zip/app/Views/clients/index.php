<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h3>Data Pelanggan</h3>
    <a href="/clients/create" class="btn btn-primary">Tambah Pelanggan</a>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>No HP/WA</th>
                        <th>Email</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($clients)): ?>
                        <tr><td colspan="4" class="text-center">Belum ada data pelanggan.</td></tr>
                    <?php else: ?>
                        <?php foreach($clients as $c): ?>
                        <tr>
                            <td><?= esc($c['client_name']) ?></td>
                            <td><?= esc($c['client_phone']) ?></td>
                            <td><?= esc($c['client_email']) ?></td>
                            <td>
                                <a href="/clients/edit/<?= $c['id'] ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                                <form action="/clients/delete/<?= $c['id'] ?>" method="post" class="d-inline" onsubmit="return confirm('Yakin hapus pelanggan ini?');">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button type="submit" class="btn btn-sm btn-outline-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <?= $pager->links() ?>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
