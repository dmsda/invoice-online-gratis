<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <h3 class="mb-4">Pengaturan Profil Usaha</h3>

        <?php if(session()->getFlashdata('success')): ?>
            <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
        <?php endif; ?>

        <?php if(session()->getFlashdata('errors')): ?>
            <div class="alert alert-danger">
                <ul>
                <?php foreach(session()->getFlashdata('errors') as $error): ?>
                    <li><?= esc($error) ?></li>
                <?php endforeach ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card shadow-sm">
            <div class="card-body">
                <form action="/settings/update_profile" method="post" enctype="multipart/form-data">
                    <?= csrf_field() ?>
                    
                    <h5 class="mb-3 text-primary">Identitas Usaha</h5>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label class="form-label">Logo Usaha</label>
                            <?php if(!empty($profile['logo_path'])): ?>
                                <div class="mb-2">
                                    <img src="/<?= esc($profile['logo_path']) ?>" alt="Logo" class="img-thumbnail" style="max-height: 100px;">
                                </div>
                            <?php endif; ?>
                            <input type="file" name="logo" class="form-control form-control-sm">
                            <small class="text-muted">Format: JPG/PNG, Max 1MB.</small>
                        </div>
                        <div class="col-md-8">
                            <div class="mb-3">
                                <label class="form-label">Nama Bisnis / Usaha <span class="text-danger">*</span></label>
                                <input type="text" name="business_name" class="form-control" value="<?= esc($profile['business_name']) ?>" required>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">No. Telepon / WA</label>
                                    <input type="text" name="business_phone" class="form-control" value="<?= esc($profile['business_phone']) ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Email Publik</label>
                                    <input type="email" name="business_email" class="form-control" value="<?= esc($profile['business_email']) ?>">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Alamat Lengkap</label>
                        <textarea name="business_address" class="form-control" rows="2"><?= esc($profile['business_address']) ?></textarea>
                        <small class="text-muted">Akan muncul di Kop Invoice.</small>
                    </div>

                    <hr>
                    <h5 class="mb-3 text-primary">Data Pembayaran (Bank)</h5>
                    
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Nama Bank</label>
                            <input type="text" name="bank_name" class="form-control" placeholder="BCA / Mandiri" value="<?= esc($profile['bank_name']) ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Nomor Rekening</label>
                            <input type="text" name="bank_number" class="form-control" placeholder="1234567890" value="<?= esc($profile['bank_number']) ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Atas Nama</label>
                            <input type="text" name="bank_account_name" class="form-control" placeholder="Nama Pemilik" value="<?= esc($profile['bank_account_name']) ?>">
                        </div>
                    </div>

                    <div class="d-grid mt-4">
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
