<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="mb-3 d-flex justify-content-between align-items-center">
    <div>
        <a href="/invoices" class="btn btn-outline-secondary">&larr; Kembali</a>
    </div>
</div>

<div class="row">
    <div class="col-md-9">
        <div class="card shadow">
            <div class="card-body p-5">
                <!-- Header -->
                <div class="row mb-4">
                    <div class="col-6">
                        <h4>INVOICE</h4>
                        <span class="text-muted"><?= esc($invoice['invoice_number']) ?></span>
                    </div>
                    <div class="col-6 text-end">
                        <h4 class="<?= str_replace('bg-', 'text-', status_badge_class($invoice['status'])) ?>">
                            <?= strtoupper(status_label_id($invoice['status'])) ?>
                        </h4>
                    </div>
                </div>

                <!-- Info -->
                <div class="row mb-4">
                    <div class="col-6">
                        <strong>Ditagihkan Ke:</strong><br>
                        <?= esc($invoice['client_name']) ?><br>
                        <?= nl2br(esc($invoice['client_address'])) ?><br>
                        <?= esc($invoice['client_phone']) ?>
                    </div>
                    <div class="col-6 text-end">
                        <strong>Tanggal:</strong> <?= date('d/m/Y', strtotime($invoice['date_issued'])) ?><br>
                        <strong>Jatuh Tempo:</strong> <?= $invoice['due_date'] ? date('d/m/Y', strtotime($invoice['due_date'])) : '-' ?>
                    </div>
                </div>

                <!-- Items -->
                <table class="table table-bordered mb-4">
                    <thead class="table-light">
                        <tr>
                            <th>Deskripsi</th>
                            <th class="text-end">Qty</th>
                            <th class="text-end">Harga</th>
                            <th class="text-end">Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($items as $item): ?>
                        <tr>
                            <td>
                                <strong><?= esc($item['item_name']) ?></strong><br>
                                <small class="text-muted"><?= esc($item['description']) ?></small>
                            </td>
                            <td class="text-end"><?= number_format($item['quantity'], 0, ',', '.') ?></td>
                            <td class="text-end">Rp <?= number_format($item['price'], 0, ',', '.') ?></td>
                            <td class="text-end">Rp <?= number_format($item['amount'], 0, ',', '.') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-end">Subtotal</td>
                            <td class="text-end">Rp <?= number_format($invoice['subtotal'], 0, ',', '.') ?></td>
                        </tr>
                        <?php if($invoice['discount'] > 0): ?>
                        <tr>
                            <td colspan="3" class="text-end">Diskon</td>
                            <td class="text-end">- Rp <?= number_format($invoice['discount'], 0, ',', '.') ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if($invoice['tax'] > 0): ?>
                        <tr>
                            <td colspan="3" class="text-end">Pajak</td>
                            <td class="text-end">+ Rp <?= number_format($invoice['tax'], 0, ',', '.') ?></td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <td colspan="3" class="text-end"><strong>Total</strong></td>
                            <td class="text-end"><strong>Rp <?= number_format($invoice['total_amount'], 0, ',', '.') ?></strong></td>
                        </tr>
                    </tfoot>
                </table>

                <?php if($invoice['notes']): ?>
                <div class="alert alert-light border">
                    <strong>Catatan:</strong><br>
                    <?= nl2br(esc($invoice['notes'])) ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Sidebar Actions -->
    <div class="col-md-3">
        <div class="card shadow-sm mb-3">
            <div class="card-body">
                <h5 class="card-title">Aksi</h5>
                <?php if($invoice['status'] == 'draft'): ?>
                    <a href="/invoices/edit/<?= $invoice['uuid'] ?>" class="btn btn-warning w-100 mb-3"><i class="bi bi-pencil"></i> Edit Invoice</a>
                <?php endif; ?>
                <form action="/invoices/status/<?= $invoice['uuid'] ?>" method="post">
                    <?= csrf_field() ?>
                    <label class="form-label">Ubah Status:</label>
                    <select name="status" class="form-select mb-2" onchange="this.form.submit()" <?= $invoice['status'] == 'paid' ? 'disabled' : '' ?>>
                        <option value="draft" <?= $invoice['status'] == 'draft' ? 'selected' : '' ?>>Draft</option>
                        <option value="sent" <?= $invoice['status'] == 'sent' ? 'selected' : '' ?>>Sent</option>
                        <option value="paid" <?= $invoice['status'] == 'paid' ? 'selected' : '' ?>>Paid</option>
                        <option value="canceled" <?= $invoice['status'] == 'canceled' ? 'selected' : '' ?>>Canceled</option>
                    </select>
                </form>
                <hr>
                <a href="/invoices/pdf/<?= $invoice['uuid'] ?>" class="btn btn-outline-primary w-100 mb-2" target="_blank">Download PDF</a>
                <a href="/v/<?= $invoice['uuid'] ?>" class="btn btn-outline-info w-100 mb-2" target="_blank">Lihat Public Link</a>
                
                <?php if($invoice['status'] !== 'draft'): ?>
                    <?php if(!empty($invoice['client_phone'])): ?>
                        <?php 
                            $waMessage = "Halo " . $invoice['client_name'] . ",\n" .
                                         "Berikut kami kirimkan invoice *" . $invoice['invoice_number'] . "*\n" .
                                         "Total: " . format_rupiah($invoice['total_amount']) . "\n\n" .
                                         "Silakan cek melalui link berikut:\n" .
                                         base_url('v/' . $invoice['uuid']) . "\n\n" .
                                         "Terima kasih.";
                            $waLink = generate_wa_link($invoice['client_phone'], $waMessage);
                        ?>
                        <a href="<?= $waLink ?>" class="btn btn-success w-100" target="_blank">
                            <i class="bi bi-whatsapp"></i> Kirim via WhatsApp
                        </a>
                    <?php else: ?>
                        <button class="btn btn-secondary w-100" disabled title="No HP Klien tidak ada">
                            Kirim via WhatsApp (No HP Kosong)
                        </button>
                    <?php endif; ?>
                <?php else: ?>
                    <button class="btn btn-secondary w-100" disabled title="Tersedia setelah status Sent/Paid">
                        Kirim via WhatsApp (Draft)
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
