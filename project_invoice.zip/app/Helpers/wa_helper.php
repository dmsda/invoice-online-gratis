<?php

if (! function_exists('generate_wa_link')) {
    function generate_wa_link($phone, $message)
    {
        // 1. Clean phone number
        $phone = preg_replace('/[^0-9]/', '', $phone); // Remove non-numeric

        // 2. Format to international (ID)
        if (substr($phone, 0, 1) === '0') {
            $phone = '62' . substr($phone, 1);
        } elseif (substr($phone, 0, 2) !== '62') {
            // Assume if not starting with 0 or 62, it might need 62 prefix if it seems like a local number without 0
            // But safest is to assume user might input 812...
            $phone = '62' . $phone;
        }

        // 3. Encode message
        $encodedMessage = rawurlencode($message);

        // 4. Return URL
        return "https://wa.me/{$phone}?text={$encodedMessage}";
    }
}

if (! function_exists('format_rupiah')) {
    function format_rupiah($angka)
    {
        return "Rp " . number_format($angka, 0, ',', '.');
    }
}
