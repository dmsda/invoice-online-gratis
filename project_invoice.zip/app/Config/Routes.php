<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// Auth Routes
$routes->get('/', 'Home::index'); // Landing Page
$routes->get('/login', 'Auth::login');
$routes->post('/login', 'Auth::process_login');
$routes->get('/register', 'Auth::register');
$routes->post('/register', 'Auth::process_register');
$routes->get('/logout', 'Auth::logout');

// Dashboard Routes (Protected)
$routes->group('', ['filter' => 'auth'], function($routes) {
    $routes->get('/dashboard', 'Dashboard::index');
    
    // Clients Routes
    $routes->group('clients', function($routes) {
        $routes->get('/', 'Clients::index');
        $routes->get('create', 'Clients::create');
        $routes->post('store', 'Clients::store');
        $routes->post('store_ajax', 'Clients::store_ajax');
        $routes->get('edit/(:num)', 'Clients::edit/$1');
        $routes->post('update/(:num)', 'Clients::update/$1');
        $routes->post('delete/(:num)', 'Clients::delete/$1');
    });

    // Invoices Routes
    $routes->group('invoices', function($routes) {
        $routes->get('/', 'Invoices::index');
        $routes->get('create', 'Invoices::create');
        $routes->post('store', 'Invoices::store');
        $routes->get('edit/(:segment)', 'Invoices::edit/$1');
        $routes->post('update/(:segment)', 'Invoices::update/$1');
        $routes->get('show/(:segment)', 'Invoices::show/$1');
        $routes->get('pdf/(:segment)', 'Invoices::downloadPdf/$1');
        $routes->post('status/(:segment)', 'Invoices::updateStatus/$1');
        $routes->post('delete/(:segment)', 'Invoices::delete/$1');
    });

    // Settings Routes
    $routes->get('/settings/profile', 'Settings::profile');
    $routes->post('/settings/update_profile', 'Settings::update_profile');
});

// Public Routes
$routes->get('/v/(:segment)', 'PublicInvoice::index/$1'); // UUID (Public View)
