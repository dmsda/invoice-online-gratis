<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="mb-3">
    <a href="/invoices" class="btn btn-outline-secondary">&larr; Kembali</a>
</div>

<h3 class="mb-4">Edit Invoice <?= esc($invoice['invoice_number']) ?></h3>
<?php if(session()->getFlashdata('error')): ?>
    <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
<?php endif; ?>

<?php if($invoice['status'] != 'draft'): ?>
    <div class="alert alert-warning">
        <i class="bi bi-exclamation-triangle"></i> Peringatan: Invoice ini statusnya <strong><?= ucfirst($invoice['status']) ?></strong>. 
        Disarankan hanya mengedit invoice yang masih Draft.
    </div>
<?php endif; ?>

<form action="/invoices/update/<?= $invoice['uuid'] ?>" method="post" x-data="invoiceForm()" @submit="isSaving = true">
    <?= csrf_field() ?>
    
    <div class="row">
        <!-- HEADER -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-light"><strong>Info Invoice</strong></div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Pilih Pelanggan <span class="text-danger">*</span></label>
                        <select name="client_id" class="form-select" x-model="clientId" required>
                            <option value="">-- Pilih --</option>
                            <template x-for="client in clients" :key="client.id">
                                <option :value="client.id" x-text="client.client_name" :selected="client.id == clientId"></option>
                            </template>
                        </select>
                        <small>
                             <!-- Modals for adding client not included in Edit to keep it simple, or can be added if needed -->
                            <span class="text-muted">Untuk tambah pelanggan baru, silakan ke menu Pelanggan.</span>
                        </small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Judul (Opsional)</label>
                        <input type="text" name="title" class="form-control" placeholder="Contoh: Tagihan Jasa Web" value="<?= esc($invoice['title']) ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Tanggal Terbit <span class="text-danger">*</span></label>
                        <input type="date" name="date_issued" class="form-control" value="<?= $invoice['date_issued'] ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Jatuh Tempo</label>
                        <input type="date" name="due_date" class="form-control" value="<?= $invoice['due_date'] ?>">
                    </div>
                </div>
            </div>
        </div>

        <!-- ITEMS -->
        <div class="col-md-8 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-light"><strong>Item Tagihan</strong></div>
                <div class="card-body p-0">
                    <table class="table table-bordered mb-0">
                        <thead class="table-light">
                            <tr>
                                <th width="40%">Item / Jasa</th>
                                <th width="15%">Qty</th>
                                <th width="25%">Harga</th>
                                <th width="15%">Total</th>
                                <th width="5%"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <template x-for="(item, index) in items" :key="index">
                                <tr>
                                    <td>
                                        <input type="text" :name="'items[item_name][]'" x-model="item.item_name" class="form-control form-control-sm mb-1" placeholder="Nama Item" required>
                                        <textarea :name="'items[description][]'" x-model="item.description" class="form-control form-control-sm" placeholder="Deskripsi (Opsional)" rows="1"></textarea>
                                    </td>
                                    <td>
                                        <input type="number" :name="'items[quantity][]'" x-model="item.quantity" class="form-control form-control-sm" required min="1">
                                    </td>
                                    <td>
                                        <input type="number" :name="'items[price][]'" x-model="item.price" class="form-control form-control-sm" required min="0">
                                    </td>
                                    <td class="text-end">
                                        Rp <span x-text="formatNumber(item.quantity * item.price)"></span>
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-danger" @click="removeItem(index)" x-show="items.length > 1">&times;</button>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="5">
                                    <button type="button" class="btn btn-sm btn-success" @click="addItem()">+ Tambah Baris</button>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="card-footer bg-white">
                    <div class="row justify-content-end text-end">
                        <div class="col-md-6">
                            <div class="d-flex justify-content-between mb-2">
                                <span>Subtotal:</span>
                                <strong>Rp <span x-text="formatNumber(subtotal())"></span></strong>
                            </div>
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span>Diskon (Rp):</span>
                                <input type="number" name="discount" x-model="discount" class="form-control form-control-sm w-50 text-end">
                            </div>
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span>Pajak (Rp):</span>
                                <input type="number" name="tax" x-model="tax" class="form-control form-control-sm w-50 text-end">
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between">
                                <h4>Total:</h4>
                                <h4 class="text-primary">Rp <span x-text="formatNumber(grandTotal())"></span></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mt-3 shadow-sm">
                <div class="card-body">
                    <label class="form-label">Catatan / Footer Invoice</label>
                    <textarea name="notes" class="form-control" rows="3" placeholder="Contoh: Transfer ke BCA 123456..."><?= esc($invoice['notes']) ?></textarea>
                </div>
            </div>

            <div class="d-grid mt-4">
                <button type="submit" class="btn btn-lg btn-primary" :disabled="isSaving">
                    <span x-show="isSaving" class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                    <span x-text="isSaving ? 'Menyimpan Perubahan...' : 'Update Invoice'"></span>
                </button>
            </div>
        </div>
    </div>
</form>

<script>
    var initialClients = <?= json_encode(array_map(function($c){
        return ['id' => $c['id'], 'client_name' => $c['client_name']];
    }, $clients)) ?>;

    // Use json_encode options to ensure numbers are numbers not strings if possible, 
    // but PHP decimal/float types might be strings in CodeIgniter return type array.
    // So we handle parsing in JS.
    var existingItems = <?= json_encode($items) ?>;
    var existingClientId = <?= $invoice['client_id'] ?>;
    var existingDiscount = <?= $invoice['discount'] ?>;
    var existingTax = <?= $invoice['tax'] ?>;

    function invoiceForm() {
        return {
            clients: initialClients,
            clientId: existingClientId,
            items: existingItems.map(item => ({
                item_name: item.item_name,
                description: item.description || '',
                quantity: parseFloat(item.quantity),
                price: parseFloat(item.price)
            })),
            discount: parseFloat(existingDiscount),
            tax: parseFloat(existingTax),
            
            isSaving: false,

            addItem() {
                this.items.push({ item_name: '', description: '', quantity: 1, price: 0 });
            },
            removeItem(index) {
                this.items.splice(index, 1);
            },
            subtotal() {
                return this.items.reduce((sum, item) => sum + (item.quantity * item.price), 0);
            },
            grandTotal() {
                return this.subtotal() - this.discount + parseInt(this.tax || 0);
            },
            formatNumber(num) {
                return new Intl.NumberFormat('id-ID').format(num);
            }
        }
    }
</script>
<?= $this->endSection() ?>
