<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
    public function index()
    {
        $userId = session()->get('id');
        $invoiceModel = new \App\Models\InvoiceModel();
        $clientModel = new \App\Models\ClientModel();

        // Stats
        $totalInvoices = $invoiceModel->where('user_id', $userId)->countAllResults();
        $unpaidInvoices = $invoiceModel->where('user_id', $userId)
                                       ->whereIn('status', ['sent', 'draft']) // Draft/Sent considered unpaid
                                       ->countAllResults();
        $paidInvoices = $invoiceModel->where('user_id', $userId)
                                     ->where('status', 'paid')
                                     ->countAllResults();
                                     
        $totalClients = $clientModel->where('user_id', $userId)->countAllResults();

        // Recent Invoices
        $recentInvoices = $invoiceModel->select('invoices.*, clients.client_name')
                                       ->join('clients', 'clients.id = invoices.client_id', 'left')
                                       ->where('invoices.user_id', $userId)
                                       ->orderBy('invoices.created_at', 'DESC')
                                       ->findAll(5);

        return view('dashboard/index', [
            'title' => 'Dashboard',
            'totalInvoices' => $totalInvoices,
            'unpaidInvoices' => $unpaidInvoices,
            'paidInvoices' => $paidInvoices,
            'totalClients' => $totalClients,
            'recentInvoices' => $recentInvoices
        ]);
    }
}
