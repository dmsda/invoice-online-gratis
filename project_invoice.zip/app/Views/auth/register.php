<!doctype html>
<html lang="id">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register - Invoice Online Gratis</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        body { background-color: #f8f9fa; }
        .register-card { max-width: 500px; margin: 50px auto; }
    </style>
  </head>
  <body>
    <div class="container">
        <div class="card register-card shadow-sm">
            <div class="card-body p-4">
                <h3 class="text-center mb-4">Daftar Akun Baru</h3>
                
                <?php if(session()->getFlashdata('errors')):?>
                    <div class="alert alert-danger">
                        <ul>
                        <?php foreach(session()->getFlashdata('errors') as $error): ?>
                            <li><?= esc($error) ?></li>
                        <?php endforeach ?>
                        </ul>
                    </div>
                <?php endif;?>

                <form action="/register" method="post" x-data="{ loading: false, showPass: false, showConf: false }" @submit="loading = true">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" name="email" class="form-control" id="email" value="<?= old('email') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <div class="input-group">
                            <input :type="showPass ? 'text' : 'password'" name="password" class="form-control" id="password" required>
                            <button class="btn btn-outline-secondary" type="button" @click="showPass = !showPass">
                                <i :class="showPass ? 'bi bi-eye-slash' : 'bi bi-eye'"></i>
                            </button>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="confpassword" class="form-label">Konfirmasi Password</label>
                        <div class="input-group">
                            <input :type="showConf ? 'text' : 'password'" name="confpassword" class="form-control" id="confpassword" required>
                            <button class="btn btn-outline-secondary" type="button" @click="showConf = !showConf">
                                <i :class="showConf ? 'bi bi-eye-slash' : 'bi bi-eye'"></i>
                            </button>
                        </div>
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary" :disabled="loading">
                            <span x-show="loading" class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                            <span x-text="loading ? 'Memproses...' : 'Lanjut Bikin Invoice'"></span>
                        </button>
                        <small class="text-center mt-2 text-muted">Data Anda aman & terenkripsi.</small>
                    </div>
                </form>
                <div class="mt-3 text-center">
                    Sudah punya akun? <a href="/login">Login di sini</a>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
