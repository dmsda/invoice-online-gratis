<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="mb-3">
    <a href="/invoices" class="btn btn-outline-secondary">&larr; Kembali</a>
</div>

<h3 class="mb-4">Buat Invoice Baru</h3>

<form action="/invoices/store" method="post" x-data="invoiceForm()" @submit="isSaving = true">
    <?= csrf_field() ?>
    
    <div class="row">
        <!-- HEADER -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-header bg-light"><strong>Info Invoice</strong></div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Pilih Pelanggan <span class="text-danger">*</span></label>
                        <select name="client_id" class="form-select" x-model="clientId" required>
                            <option value="">-- Pilih --</option>
                            <template x-for="client in clients" :key="client.id">
                                <option :value="client.id" x-text="client.client_name"></option>
                            </template>
                        </select>
                        <small>
                            <a href="#" data-bs-toggle="modal" data-bs-target="#addClientModal" class="text-decoration-none fw-bold">
                                <i class="bi bi-plus-circle"></i> Tambah Pelanggan Baru
                            </a>
                        </small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Judul (Opsional)</label>
                        <input type="text" name="title" class="form-control" placeholder="Contoh: Tagihan Jasa Web" value="INVOICE">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Tanggal Terbit <span class="text-danger">*</span></label>
                        <input type="date" name="date_issued" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Jatuh Tempo</label>
                        <input type="date" name="due_date" class="form-control">
                    </div>
                </div>
            </div>
        </div>

        <!-- ITEMS -->
        <div class="col-md-8 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-light"><strong>Item Tagihan</strong></div>
                <div class="card-body p-0">
                    <table class="table table-bordered mb-0">
                        <thead class="table-light">
                            <tr>
                                <th width="40%">Item / Jasa</th>
                                <th width="15%">Qty</th>
                                <th width="25%">Harga</th>
                                <th width="15%">Total</th>
                                <th width="5%"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <template x-for="(item, index) in items" :key="index">
                                <tr>
                                    <td>
                                        <input type="text" :name="'items[item_name][]'" class="form-control form-control-sm mb-1" placeholder="Nama Item" required>
                                        <textarea :name="'items[description][]'" class="form-control form-control-sm" placeholder="Deskripsi (Opsional)" rows="1"></textarea>
                                    </td>
                                    <td>
                                        <input type="number" :name="'items[quantity][]'" x-model="item.qty" class="form-control form-control-sm" required min="1">
                                    </td>
                                    <td>
                                        <input type="number" :name="'items[price][]'" x-model="item.price" class="form-control form-control-sm" required min="0">
                                    </td>
                                    <td class="text-end">
                                        Rp <span x-text="formatNumber(item.qty * item.price)"></span>
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-danger" @click="removeItem(index)" x-show="items.length > 1">&times;</button>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="5">
                                    <button type="button" class="btn btn-sm btn-success" @click="addItem()">+ Tambah Baris</button>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="card-footer bg-white">
                    <div class="row justify-content-end text-end">
                        <div class="col-md-6">
                            <div class="d-flex justify-content-between mb-2">
                                <span>Subtotal:</span>
                                <strong>Rp <span x-text="formatNumber(subtotal())"></span></strong>
                            </div>
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span>Diskon (Rp):</span>
                                <input type="number" name="discount" x-model="discount" class="form-control form-control-sm w-50 text-end">
                            </div>
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span>Pajak (Rp):</span>
                                <input type="number" name="tax" x-model="tax" class="form-control form-control-sm w-50 text-end">
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between">
                                <h4>Total:</h4>
                                <h4 class="text-primary">Rp <span x-text="formatNumber(grandTotal())"></span></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mt-3 shadow-sm">
                <div class="card-body">
                    <label class="form-label">Catatan / Footer Invoice</label>
                    <textarea name="notes" class="form-control" rows="3" placeholder="Contoh: Transfer ke BCA 123456..."></textarea>
                </div>
            </div>

            <div class="d-grid mt-4">
                <button type="submit" class="btn btn-lg btn-primary" :disabled="isSaving">
                    <span x-show="isSaving" class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                    <span x-text="isSaving ? 'Menyimpan Invoice...' : 'Simpan & Jadi PDF'"></span>
                </button>
                <small class="text-center mt-2 text-muted">Draft otomatis tersimpan. Jangan khawatir hilang.</small>
            </div>
        </div>
    </div>
</form>

<script>
    var initialClients = <?= json_encode(array_map(function($c){
        return ['id' => $c['id'], 'client_name' => $c['client_name']];
    }, $clients)) ?>;
</script>

<div class="modal fade" id="addClientModal" tabindex="-1" aria-labelledby="addClientModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addClientModalLabel">Tambah Pelanggan Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div x-show="clientSuccess" class="alert alert-success">
                    Pelanggan berhasil ditambahkan!
                </div>
                <!-- Client Form inside Modal -->
                <form @submit.prevent="saveClient()">
                    <div class="mb-3">
                        <label class="form-label">Nama Pelanggan <span class="text-danger">*</span></label>
                        <input type="text" x-model="newClient.client_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">No. WhatsApp</label>
                        <input type="text" x-model="newClient.client_phone" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" x-model="newClient.client_email" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Alamat</label>
                        <textarea x-model="newClient.client_address" class="form-control" rows="2"></textarea>
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary" :disabled="clientLoading">
                            <span x-show="clientLoading" class="spinner-border spinner-border-sm me-1"></span>
                            Simpan Pelanggan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function invoiceForm() {
        return {
            clients: initialClients,
            clientId: '', // Model for the select
            items: [
                { qty: 1, price: 0 }
            ],
            discount: 0,
            tax: 0,
            
            // Client Modal State
            newClient: {
                client_name: '',
                client_phone: '',
                client_email: '',
                client_address: ''
            },
            clientLoading: false,
            clientSuccess: false,
            
            // Loading state for main form
            isSaving: false,

            addItem() {
                this.items.push({ qty: 1, price: 0 });
            },
            removeItem(index) {
                this.items.splice(index, 1);
            },
            subtotal() {
                return this.items.reduce((sum, item) => sum + (item.qty * item.price), 0);
            },
            grandTotal() {
                return this.subtotal() - this.discount + parseInt(this.tax || 0);
            },
            formatNumber(num) {
                return new Intl.NumberFormat('id-ID').format(num);
            },
            
            // Save Client via AJAX
            saveClient() {
                this.clientLoading = true;
                this.clientSuccess = false;
                
                let formData = new FormData();
                formData.append('client_name', this.newClient.client_name);
                formData.append('client_phone', this.newClient.client_phone);
                formData.append('client_email', this.newClient.client_email);
                formData.append('client_address', this.newClient.client_address);
                formData.append('<?= csrf_token() ?>', '<?= csrf_hash() ?>'); // CSRF

                fetch('/clients/store_ajax', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    this.clientLoading = false;
                    if(data.status === 'success') {
                        // Add to list and select it
                        this.clients.push(data.data);
                        this.clientId = data.data.id; // Select the new client
                        
                        // Reset form
                        this.newClient = { client_name: '', client_phone: '', client_email: '', client_address: '' };
                        this.clientSuccess = true;

                        // Close modal after 1s
                        setTimeout(() => {
                            var myModalEl = document.getElementById('addClientModal');
                            var modal = bootstrap.Modal.getInstance(myModalEl);
                            modal.hide();
                            this.clientSuccess = false;
                        }, 1000);
                    } else {
                        alert('Gagal: ' + JSON.stringify(data.errors));
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    this.clientLoading = false;
                    alert('Terjadi kesalahan koneksi.');
                });
            }
        }
    }
</script>
<?= $this->endSection() ?>
