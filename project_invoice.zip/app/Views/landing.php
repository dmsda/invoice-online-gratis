<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buat Invoice Online Gratis & Kirim via WhatsApp - Tanpa Ribet</title>
    <meta name="description" content="Buat invoice online gratis dalam 30 detik. Langsung jadi PDF siap kirim via WhatsApp. Solusi praktis untuk UMKM & Freelancer.">
    
    <!-- Open Graph / Social Media -->
    <!-- Canonical -->
    <link rel="canonical" href="https://invoiceonlinegratis.com/">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://invoiceonlinegratis.com/">
    <meta property="og:title" content="Buat Invoice Online Gratis & Kirim via WhatsApp - Tanpa Ribet">
    <meta property="og:description" content="Cara termudah buat invoice UMKM. Tanpa ribet, langsung jadi PDF siap kirim via WhatsApp. Gratis selamanya.">
    <meta property="og:image" content="https://invoiceonlinegratis.com/assets/img/og-image.jpg">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="https://invoiceonlinegratis.com/">
    <meta property="twitter:title" content="Buat Invoice Online Gratis & Kirim via WhatsApp">
    <meta property="twitter:description" content="Cara termudah buat invoice UMKM. Tanpa ribet, langsung jadi PDF siap kirim via WhatsApp. Gratis selamanya.">
    <meta property="twitter:image" content="https://invoiceonlinegratis.com/assets/img/og-image.jpg">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    
    <style>
        body { font-family: 'Inter', sans-serif; line-height: 1.6; color: #333; }
        .hero-section { background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%); color: white; padding: 100px 0 80px; }
        .feature-icon { font-size: 2.5rem; color: #0d6efd; margin-bottom: 1rem; }
        .bg-light-soft { background-color: #f8f9fa; }
        .accordion-button:not(.collapsed) { background-color: #e7f1ff; color: #0c63e4; }
        .cta-section { background-color: #0d6efd; color: white; padding: 60px 0; }
        .navbar-brand { font-weight: bold; font-size: 1.5rem; }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm fixed-top">
        <div class="container">
            <a class="navbar-brand text-primary" href="#">Invoice Online <span class="text-dark">Gratis</span></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item"><a class="nav-link py-2" href="#cara-kerja">Cara Kerja</a></li>
                    <li class="nav-item"><a class="nav-link py-2" href="#fitur">Fitur</a></li>
                    <li class="nav-item"><a class="nav-link py-2" href="#faq">FAQ</a></li>
                    <li class="nav-item ms-lg-3">
                        <a href="/login" class="btn btn-outline-primary me-2">Masuk</a>
                        <a href="/register" class="btn btn-primary">Daftar Gratis</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section text-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <h1 class="display-4 fw-bold mb-4">Buat Invoice Online Gratis dalam 30 Detik (Tanpa Ribet)</h1>
                    <p class="lead mb-5 opacity-90">Kirim tagihan profesional ke klien lewat WhatsApp langsung dari HP Anda. Cepat, mudah, dan gratis selamanya.</p>
                    <div class="d-flex justify-content-center gap-3 flex-column flex-sm-row">
                        <a href="/register" class="btn btn-light btn-lg text-primary fw-bold px-5">Buat Invoice Sekarang <i class="bi bi-arrow-right"></i></a>
                        <a href="#cara-kerja" class="btn btn-outline-light btn-lg px-4">Lihat Cara Kerja</a>
                    </div>
                    <div class="mt-3 small opacity-75">
                        Tanpa kartu kredit. Langsung aktif.
                    </div>
                    <div class="mt-4 small opacity-75">
                        <i class="bi bi-check-circle-fill me-1"></i> Gratis Selamanya &nbsp;
                        <i class="bi bi-check-circle-fill me-1"></i> Langsung Jadi PDF &nbsp;
                        <i class="bi bi-check-circle-fill me-1"></i> Kirim via WhatsApp &nbsp;
                        <i class="bi bi-check-circle-fill me-1"></i> Tanpa Install Aplikasi
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Problem Section -->
    <section class="py-5 bg-white">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Masih Pusing Ngurusin Tagihan Manual?</h2>
                <p class="text-muted">Jangan biarkan urusan administrasi menghambat rezeki Anda. Sering mengalami ini?</p>
            </div>
            <div class="row g-4 text-center">
                <div class="col-md-3">
                    <div class="p-3">
                        <div class="display-6 mb-3">🤯</div>
                        <h5>Ribet Pakai Excel</h5>
                        <p class="small text-muted">Harus buka laptop, atur kolom, dan rumus sering error.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="p-3">
                        <div class="display-6 mb-3">📝</div>
                        <h5>Nota Tulis Tangan</h5>
                        <p class="small text-muted">Kertas sering hilang, tulisan sulit dibaca, dan terlihat kurang profesional.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="p-3">
                        <div class="display-6 mb-3">💬</div>
                        <h5>Tagihan Tenggelam</h5>
                        <p class="small text-muted">Kirim foto nota di WhatsApp seringkali tidak terbaca atau tertumpuk chat lain.</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="p-3">
                        <div class="display-6 mb-3">❓</div>
                        <h5>Klien Bingung</h5>
                        <p class="small text-muted">Total bayar tidak jelas karena tulisan tangan atau format berantakan.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works Section (Moved Up) -->
    <section id="cara-kerja" class="py-5 bg-light-soft">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Cara Membuat Invoice Online dalam 3 Langkah</h2>
                <p class="text-muted">Proses cepat, mudah, dan bisa langsung cair.</p>
            </div>
            <div class="row g-4 text-center">
                <div class="col-md-4">
                    <div class="p-3">
                        <div class="display-1 fw-bold text-primary mb-3">1</div>
                        <h3 class="h5 fw-bold">Daftar Gratis & Masuk</h3>
                        <p class="text-muted small">Buat akun hanya dalam hitungan detik. Tidak perlu kartu kredit, tidak ada masa uji coba, langsung aktif selamanya.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="p-3">
                        <div class="display-1 fw-bold text-primary mb-3">2</div>
                        <h3 class="h5 fw-bold">Isi Data Invoice</h3>
                        <p class="text-muted small">Masukkan nama klien dan rincian produk/jasa. Sistem otomatis menghitung total harga, jadi Anda tidak perlu repot.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="p-3">
                        <div class="display-1 fw-bold text-primary mb-3">3</div>
                        <h3 class="h5 fw-bold">Download atau Kirim</h3>
                        <p class="text-muted small">Simpan invoice sebagai PDF siap cetak atau salin link unik untuk dikirim via WhatsApp. Praktis!</p>
                    </div>
                </div>
            </div>
            <div class="text-center mt-5">
                <a href="/register" class="btn btn-primary btn-lg px-5 shadow-sm">Mulai Gratis <i class="bi bi-arrow-right"></i></a>
                <p class="small text-muted mt-2">Hanya butuh email. 30 detik selesai.</p>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="fitur" class="py-5 bg-white">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Fitur Utama Invoice Online Gratis</h2>
                <p class="text-muted">Semua yang Anda butuhkan untuk kelola tagihan dengan mudah.</p>
            </div>
            <div class="row g-4 justify-content-center">
                <!-- Feature 1 -->
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body p-4 text-center">
                            <i class="bi bi-lightning-charge-fill feature-icon"></i>
                            <h3 class="h5 fw-bold">Buat Invoice Online</h3>
                            <p class="text-muted small">Cukup isi data pelanggan, sistem kami membuatkan invoice profesional secara otomatis.</p>
                        </div>
                    </div>
                </div>
                <!-- Feature 2 -->
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body p-4 text-center">
                            <i class="bi bi-file-earmark-pdf-fill feature-icon"></i>
                            <h3 class="h5 fw-bold">Download PDF</h3>
                            <p class="text-muted small">Simpan sebagai file PDF ukuran A4 yang rapi dan siap cetak atau kirim.</p>
                        </div>
                    </div>
                </div>
                <!-- Feature 3 -->
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body p-4 text-center">
                            <i class="bi bi-whatsapp feature-icon"></i>
                            <h3 class="h5 fw-bold">Kirim via WhatsApp</h3>
                            <p class="text-muted small">Kirim link tagihan langsung ke WA klien denga pesan yang sudah disiapkan.</p>
                        </div>
                    </div>
                </div>
                <!-- Feature 4 -->
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body p-4 text-center">
                            <i class="bi bi-link-45deg feature-icon"></i>
                            <h3 class="h5 fw-bold">Link Online Aman</h3>
                            <p class="text-muted small">Klien tidak perlu install aplikasi untuk melihat tagihan, cukup buka link dari browser.</p>
                        </div>
                    </div>
                </div>
                <!-- Feature 5 -->
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body p-4 text-center">
                            <i class="bi bi-gift-fill feature-icon"></i>
                            <h3 class="h5 fw-bold">Gratis Selamanya</h3>
                            <p class="text-muted small">Tanpa biaya langganan, tanpa komisi potong. Buat invoice sepuasnya.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Comparison Section -->
    <section class="py-5 bg-light-soft">
        <div class="container">
             <div class="text-center mb-5">
                <h2 class="fw-bold">Kenapa Lebih Baik dari Cara Manual?</h2>
                <p class="text-muted">Bandingkan sendiri kemudahannya.</p>
            </div>
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4 mb-lg-0">
                    <ul class="list-unstyled">
                        <li class="mb-3 d-flex align-items-start">
                            <i class="bi bi-check-circle-fill text-success fs-5 me-3"></i>
                            <div>
                                <strong>Bisa Pakai HP</strong>
                                <p class="small text-muted mb-0">Bikin invoice sambil rebahan pun bisa, tanpa laptop.</p>
                            </div>
                        </li>
                        <li class="mb-3 d-flex align-items-start">
                            <i class="bi bi-check-circle-fill text-success fs-5 me-3"></i>
                            <div>
                                <strong>Otomatis Rapi</strong>
                                <p class="small text-muted mb-0">Tidak perlu pusing mengatur garis tabel Excel yang berantakan.</p>
                            </div>
                        </li>
                        <li class="mb-3 d-flex align-items-start">
                            <i class="bi bi-check-circle-fill text-success fs-5 me-3"></i>
                            <div>
                                <strong>Aman Tersimpan</strong>
                                <p class="small text-muted mb-0">Data aman di akun Anda, tidak hilang meski ganti HP.</p>
                            </div>
                        </li>
                        <li class="d-flex align-items-start">
                            <i class="bi bi-check-circle-fill text-success fs-5 me-3"></i>
                            <div>
                                <strong>Terlihat Bonafide</strong>
                                <p class="small text-muted mb-0">Format PDF bersih meningkatkan kepercayaan klien.</p>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-6 text-center">
                     <img src="https://placehold.co/500x400/e9ecef/adb5bd?text=Lebih+Praktis+Online" alt="Mudah dan Praktis" class="img-fluid rounded shadow-sm">
                </div>
            </div>
        </div>
    </section>

    <!-- Target Audience Section -->
    <section class="py-5 bg-white">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Siapa yang Butuh Invoice Online Gratis?</h2>
                <p class="text-muted">Didesain khusus untuk mempermudah pekerjaan Anda.</p>
            </div>
            <div class="row g-4">
                <div class="col-md-3">
                    <div class="card h-100 border-0 shadow-sm text-center">
                        <div class="card-body p-4">
                            <div class="display-6 mb-3">💻</div>
                            <h3 class="h6 fw-bold">Freelancer</h3>
                            <p class="small text-muted mb-0">Penulis, desainer, programmer.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card h-100 border-0 shadow-sm text-center">
                        <div class="card-body p-4">
                            <div class="display-6 mb-3">🏠</div>
                            <h3 class="h6 fw-bold">UMKM</h3>
                            <p class="small text-muted mb-0">Katering, laundry, kerajinan.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card h-100 border-0 shadow-sm text-center">
                        <div class="card-body p-4">
                            <div class="display-6 mb-3">🔧</div>
                            <h3 class="h6 fw-bold">Jasa Service</h3>
                            <p class="small text-muted mb-0">Tukang AC, bengkel, guru les.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card h-100 border-0 shadow-sm text-center">
                        <div class="card-body p-4">
                            <div class="display-6 mb-3">🛍️</div>
                            <h3 class="h6 fw-bold">Reseller</h3>
                            <p class="small text-muted mb-0">Dropshipper, onlineshop.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section id="faq" class="py-5 bg-light-soft">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Pertanyaan Umum tentang Invoice Online Gratis</h2>
                <p class="text-muted">Jawaban untuk keraguan Anda.</p>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="accordion" id="faqAccordion">
                        <!-- Q1 -->
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                                    Apakah Invoice Online Gratis benar-benar gratis?
                                </button>
                            </h2>
                            <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Ya, 100% gratis. Anda bisa membuat invoice, mendownload PDF, dan mengirimkannya ke klien tanpa biaya sepeserpun. Kami berkomitmen membantu UMKM tumbuh tanpa beban biaya.
                                </div>
                            </div>
                        </div>
                        <!-- Q2 -->
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                                    Apakah perlu kartu kredit atau biaya langganan?
                                </button>
                            </h2>
                            <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Tidak sama sekali. Anda hanya perlu mendaftar menggunakan alamat email. Tidak ada syarat kartu kredit, tidak ada biaya langganan bulanan, dan tidak ada biaya tersembunyi.
                                </div>
                            </div>
                        </div>
                        <!-- Q3 -->
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                                    Apakah bisa digunakan dari HP?
                                </button>
                            </h2>
                            <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Tentu saja! Website kami didesain responsif (mobile-friendly). Anda bisa membuat dan mengelola invoice langsung dari browser HP Anda, di mana saja dan kapan saja.
                                </div>
                            </div>
                        </div>
                        <!-- Q4 -->
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                                     Apakah invoice bisa dikirim ke klien?
                                </button>
                            </h2>
                            <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Sangat bisa. Setelah invoice selesai dibuat, Anda bisa menyalin link unik invoice tersebut dan mengirimkannya langsung ke WhatsApp, Email, atau media sosial klien Anda.
                                </div>
                            </div>
                        </div>
                        <!-- Q5 -->
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq5">
                                     Apakah invoice bisa di-download dalam bentuk PDF?
                                </button>
                            </h2>
                            <div id="faq5" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Ya, otomatis. Setiap invoice yang Anda buat langsung tersedia dalam format PDF standar profesional (ukuran A4) yang siap untuk didownload dan dicetak.
                                </div>
                            </div>
                        </div>
                        <!-- Q6 -->
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq6">
                                     Apakah data saya aman?
                                </button>
                            </h2>
                            <div id="faq6" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    Keamanan data adalah prioritas kami. Data invoice dan klien Anda tersimpan aman di server kami dengan enkripsi, dan hanya Anda yang memiliki akses penuh ke akun Anda.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- CTA Footer -->
    <section class="cta-section text-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <h2 class="fw-bold mb-4">Tinggalkan Cara Lama, Beralih ke Invoice Online Sekarang</h2>
                    <p class="lead mb-4">Jangan biarkan urusan tagihan menghambat bisnis Anda. Kelola invoice lebih cepat, rapi, dan profesional. Gratis selamanya, tanpa syarat ribet.</p>
                    <div class="d-flex justify-content-center gap-3 flex-column flex-sm-row">
                         <a href="/register" class="btn btn-light btn-lg text-primary fw-bold px-5 shadow-sm">Buat Invoice Gratis <i class="bi bi-arrow-right"></i></a>
                    </div>
                    <div class="mt-3 text-white opacity-75 small">
                        Gratis selamanya untuk UMKM Indonesia.
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="bg-dark text-white py-4 text-center">
        <div class="container">
            <p class="mb-0">&copy; <?= date('Y') ?> Invoice Online Gratis. Dibuat dengan ❤️ untuk UMKM Indonesia.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
